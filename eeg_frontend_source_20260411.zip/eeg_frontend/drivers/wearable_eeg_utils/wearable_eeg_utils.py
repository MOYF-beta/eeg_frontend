import asyncio
from datetime import datetime
import serial_asyncio
import struct
import matplotlib
# 设置适合无 X11 环境的后端，或使用交互式后端
try:
    import os
    if os.environ.get('DISPLAY') is None and not os.environ.get('WAYLAND_DISPLAY'):
        matplotlib.use('Agg')  # 非交互式后端
    else:
        matplotlib.use('TkAgg')  # 有 GUI 时使用 TkAgg
except Exception as e:
    print(f"[wearable_eeg_utils] Warning: Could not set matplotlib backend: {e}")
    matplotlib.use('Agg')  # 降级到 Agg

import matplotlib.pyplot as plt
from collections import deque
import numpy as np
import serial.tools.list_ports
import time
import os

baudrate = 460800

def get_ch340_ports():
    """获取CH340/CH341串口设备列表（跨平台支持）
    
    Returns:
        可用的CH340/CH341设备端口列表
    """
    import platform
    
    ch340_ports = []
    ports = serial.tools.list_ports.comports()
    
    current_system = platform.system()
    print(f"[wearable_eeg_utils] Scanning for CH340 devices on {current_system}...")
    
    for port in ports:
        # 获取设备信息
        device_name = port.device
        description = (port.description or '').upper()
        manufacturer = (port.manufacturer or '').upper()
        product = (port.product or '').upper()
        hwid = (port.hwid or '').upper()
        
        # 获取VID/PID（如果可用）
        vid = getattr(port, 'vid', None)
        pid = getattr(port, 'pid', None)
        
        # CH340/CH341检测逻辑
        is_ch340 = False
        detection_method = ""
        
        # 方法1: 检查描述中的CH340/CH341（最直接）
        if 'CH340' in description or 'CH341' in description:
            is_ch340 = True
            detection_method = "Description contains CH340/CH341"
        
        # 方法2: 检查VID/PID (CH340的VID通常是0x1A86)
        elif vid == 0x1A86:  # QinHeng Electronics (CH340制造商)
            is_ch340 = True
            detection_method = f"VID matches CH340 (0x1A86)"
        
        # 方法3: 检查HWID中的1A86 (Linux常见)
        elif '1A86' in hwid:
            is_ch340 = True
            detection_method = "HWID contains 1A86 (CH340 VID)"
        
        # 方法4: 平台特定的检测
        elif current_system == 'Linux':
            # Linux下的CH340设备通常显示为"USB SERIAL"或"USB Serial"
            device_lower = device_name.lower()
            
            # 检查是否是USB串口设备
            if device_lower.startswith('/dev/ttyusb') or device_lower.startswith('/dev/ttyacm'):
                # 检查描述是否包含USB串口相关关键词
                usb_keywords = ['USB SERIAL', 'USB_SERIAL', 'USB Serial', 'USB-Serial']
                if any(keyword in description for keyword in usb_keywords):
                    is_ch340 = True
                    detection_method = "Linux USB serial device with USB SERIAL description"
                # 如果没有明确描述，但设备名是ttyUSB且HWID包含USB，也认为是CH340
                elif device_lower.startswith('/dev/ttyusb') and 'USB' in hwid:
                    is_ch340 = True
                    detection_method = "Linux ttyUSB device with USB in HWID"
        
        elif current_system == 'Windows':
            # Windows下的检测
            if device_name.upper().startswith('COM'):
                # Windows下COM端口且描述包含USB
                if 'USB' in description and ('SERIAL' in description or 'CH340' in hwid):
                    is_ch340 = True
                    detection_method = "Windows COM port with USB serial description"
        
        if is_ch340:
            ch340_ports.append(device_name)
            print(f"[wearable_eeg_utils] Found CH340 device: {device_name}")
            print(f"  Detection method: {detection_method}")
            print(f"  Description: {description}")
            print(f"  Manufacturer: {manufacturer}")
            print(f"  Product: {product}")
            print(f"  HWID: {hwid}")
            print(f"  VID: {hex(vid) if vid else 'N/A'}")
            print(f"  PID: {hex(pid) if pid else 'N/A'}")
    
    print(f"[wearable_eeg_utils] Found {len(ch340_ports)} CH340 device(s) on {current_system}")
    return ch340_ports

def get_current_time_str():
    time_str = datetime.now().strftime("%y_%m_%d_%H_%M_%S")
    return time_str

async def init_eeg_acquiring(transport):
    print(f"[init_eeg_acquiring] Starting initialization...")
    for i in range(3):
        cmd = f"C005\r\n"
        print(f"[init_eeg_acquiring] Sending C005 command #{i+1}")
        transport.write(cmd.encode('utf-8'))
        await asyncio.sleep(0.05)
    
    for i in range(2):
        cmd = f"C002\r\n"
        print(f"[init_eeg_acquiring] Sending C002 command #{i+1}")
        transport.write(cmd.encode('utf-8'))
        await asyncio.sleep(0.01)
    
    print(f"[init_eeg_acquiring] Initialization complete!")
    print(transport)

class BCI_data_dumper(asyncio.Protocol):
    def __init__(self, output_file):
        self.output_file = output_file
        self.queue = asyncio.Queue()
        self.buffer = b''
        self.data_deque = deque(maxlen=1000)  # 存储最近1000帧数据
        self.data_received_count = 0
        self.valid_frame_count = 0

    def connection_made(self, transport):
        self.transport = transport
        print(f"[BCI_data_dumper] Connection made to {self.output_file}")

    def data_received(self, data):
        self.data_received_count += 1
        print(f"[BCI_data_dumper] data_received #{self.data_received_count}: {len(data)} bytes")
        self.buffer += data
        while b'\r\n' in self.buffer:
            line, self.buffer = self.buffer.split(b'\r\n', 1)
            print(f"[BCI_data_dumper] Parsed line: {len(line)} bytes, header: {line[:10]}")
            self.queue.put_nowait(line)

    async def write_data_to_file(self, enable_vis_cache=False):
        print(f"[BCI_data_dumper] Starting write_data_to_file, enable_vis_cache={enable_vis_cache}")
        with open(self.output_file, 'wb') as f:
            start_time = time.perf_counter()
            frame_count = 0
            while True:
                try:
                    print(f"[BCI_data_dumper] Waiting for data from queue... (total received: {self.data_received_count}, valid frames: {self.valid_frame_count})")
                    d = await asyncio.wait_for(self.queue.get(), timeout=5.0)
                    print(f"[BCI_data_dumper] Got data from queue: {len(d)} bytes")
                    if d.startswith(b'\xa5Z\x01') and len(d) == 35:
                        self.valid_frame_count += 1
                        temp = d[3:]
                        db = temp
                        if enable_vis_cache:
                            res = list(struct.unpack('<8i', db))  # 解码得到8个int
                            self.data_deque.append(res)
                            print(f"[BCI_data_dumper] Frame #{self.valid_frame_count}: {res}")

                        f.write(db)
                        elapsed = time.perf_counter() - start_time
                        f.write(struct.pack('<d', elapsed))
                        frame_count += 1
                        print(f"[BCI_data_dumper] Wrote frame #{frame_count}, elapsed={elapsed:.3f}s")
                    else:
                        print(f"[BCI_data_dumper] Invalid frame format: starts with {d[:10]}, len={len(d)}")
                except asyncio.TimeoutError:
                    print(f"[BCI_data_dumper] Queue timeout - no data received for 5 seconds")
                except asyncio.QueueEmpty:
                    print(f"[BCI_data_dumper] Queue empty, waiting...")
                    await asyncio.sleep(0.01)
                except KeyboardInterrupt:
                    print(f"[BCI_data_dumper] Interrupted by user")
                    self.transport.close()
                    f.close()
                    return
                except Exception as e:
                    print(f"[BCI_data_dumper] Error: {e}")
                    import traceback
                    traceback.print_exc()
                    self.transport.close()
                    f.close()
                    return

def read_data_from_file(file_path):
    data_list = []
    time_list = []
    
    with open(file_path, 'rb') as f:
        while True:
            # 读取数据（8个int）
            data_bytes = f.read(32)
            if not data_bytes:
                break
            data_values = struct.unpack('<8i', data_bytes)
            data_list.append(data_values)
            
            # 读取时间（1个double）
            time_bytes = f.read(8)  # 8 bytes for double
            if not time_bytes:
                break
            time_value = struct.unpack('<d', time_bytes)[0]
            time_list.append(time_value)
    
    # 将列表转换为 numpy 数组
    data_array = np.array(data_list)
    time_array = np.array(time_list)
    
    return data_array, time_array


async def plot_data(protocol, name='', max_duration=60):
    """绘制 EEG 数据
    
    Args:
        protocol: BCI_data_dumper 协议对象
        name: 图表名称
        max_duration: 最大运行时间（秒），防止无限循环
    """
    try:
        # 只在有 GUI 后端时才创建图窗
        if matplotlib.get_backend() == 'Agg':
            print("[wearable_eeg_utils] Running in non-interactive mode (Agg backend), skipping plot display")
            await asyncio.sleep(max_duration)
            return
        
        plt.ion()  # 开启交互模式
        fig, axes = plt.subplots(8, 1, figsize=(10, 15), sharex=True)  # 创建8个竖直排列的子图
        lines = [ax.plot([], [])[0] for ax in axes]  
        
        start_time = time.time()
        frame_count = 0
        
        while time.time() - start_time < max_duration:
            if protocol.data_deque:
                data = np.array(protocol.data_deque).T  
                for i, line in enumerate(lines):
                    line.set_xdata(range(len(data[i])))
                    line.set_ydata(data[i])
                    axes[i].relim()
                    axes[i].autoscale_view()
                plt.draw()
                plt.pause(0.01)
                frame_count += 1
            await asyncio.sleep(0.05)
        
        print(f"[wearable_eeg_utils] Plot task completed: {frame_count} frames rendered")
        plt.close(fig)
    except Exception as e:
        print(f"[wearable_eeg_utils] Error in plot_data: {e}")
        import traceback
        traceback.print_exc()

async def main(visualize=False):
    print(f"[main] Starting with visualize={visualize}")
    ports = get_ch340_ports()
    if not ports:
        print("[main] No CH340 devices found!")
        return
    
    com_init_tasks = []
    data_acquire_tasks = []
    
    for port in ports:
        output_file = f"{port.replace('/', '_')}_{get_current_time_str()}.eegbin"
        print(f"[main] Setting up port {port}, output file: {output_file}")
        loop = asyncio.get_running_loop()
        
        try:
            print(f"[main] Creating serial connection for {port}...")
            transport, protocol = await serial_asyncio.create_serial_connection(
                loop, lambda: BCI_data_dumper(output_file), port, baudrate=baudrate)
            print(f"[main] Serial connection created for {port}")

            data_task = asyncio.create_task(protocol.write_data_to_file(visualize))
            data_acquire_tasks.append(data_task)
            print(f"[main] Data acquisition task created")
            
            if visualize:
                print(f"[main] Creating visualization task...")
                vis_task = asyncio.create_task(plot_data(protocol, max_duration=60))
                data_acquire_tasks.append(vis_task)
            
            com_init_task = asyncio.create_task(init_eeg_acquiring(transport))
            com_init_tasks.append(com_init_task)
            print(f"[main] Initialization task created")
        except Exception as e:
            print(f"[main] Error opening port {port}: {e}")
            import traceback
            traceback.print_exc()
            continue
    
    try:
        print(f"[main] Waiting for {len(com_init_tasks)} initialization task(s)...")
        await asyncio.gather(*com_init_tasks)
        print("[main] Initialization complete, starting data acquisition...")
        print(f"[main] Waiting for {len(data_acquire_tasks)} data acquisition task(s)...")
        await asyncio.gather(*data_acquire_tasks, return_exceptions=True)
        print("[main] All tasks completed")
    except KeyboardInterrupt:
        print("\n[main] Interrupted by user")
    except Exception as e:
        print(f"[main] Error during execution: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    asyncio.run(main(True))