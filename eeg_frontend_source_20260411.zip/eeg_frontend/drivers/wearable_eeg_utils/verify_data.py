from wearable_eeg_utils import read_data_from_file

data,time = read_data_from_file('COM9_24_06_09_00_39_57.eegbin')

print(data.shape,time.shape)

print(data[:10,:])
print(time[:10])